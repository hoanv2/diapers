<div id="nf-admin-notice-upgrade" class="update-nag nf-admin-notice" style="display: none;">
    <div class="nf-notice-logo"></div>
    <p class="nf-notice-title">Achievement Unlocked</p>
    <p class="nf-notice-body">
        Cowabunga! You just unlocked Ninja Forms THREE.
    </p>
    <ul class="nf-notice-body nf-red">
        <li><span class="dashicons dashicons-awards"></span><a href="<?php echo admin_url( 'admin.php?page=ninja-forms-three' ); ?>">Update to Ninja Forms THREE</a></li>
    </ul>
</div>